﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BAL;
using BUSINESS_OBJECT;
namespace reg
{
    public partial class WebForm17 : System.Web.UI.Page
    {
        string cityname;
        string rooms;

        protected void Page_Load(object sender, EventArgs e)
        {
           // if (!IsPostBack)
            //{
                Bind();
            //}
            
        }
        private void Bind()
        {
            cityname = Session["cityname"].ToString();
            rooms = Session["rooms"].ToString();
            hotel_object ho = new hotel_object();
            register_bal cb = new register_bal();
            ho.city_name = cityname;
            ho.no_of_rooms = rooms;
            GridView1.DataSource = cb.search(ho);
            GridView1.DataBind();
        }
        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Payment.aspx");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

        }
    }
}