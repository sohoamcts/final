﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BAL;
using BUSINESS_OBJECT;
namespace reg
{
    public partial class registration : System.Web.UI.Page
    {
        Label l1 = new Label();
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            register_object ro = new register_object();

            ro.name = TextBox1.Text;
            ro.phone = TextBox2.Text;
            ro.email = TextBox3.Text;
            ro.password = TextBox4.Text;
            ro.country = TextBox6.Text;
            ro.city = TextBox7.Text;
            ro.pincode = TextBox8.Text;
            ro.securityquestion = DropDownList1.SelectedValue;
            ro.securityanswer = TextBox9.Text;
            register_bal cb = new register_bal();
            string msg = cb.insertcustomer(ro);
            if (!msg.Equals("Success"))
            {

                l1.Text = msg;
                HyperLink h1 = new HyperLink();
                h1.Text = "Login";
                Response.Redirect("login.aspx");
            }

            else
            {

                l1.Text = "Unsucessful Registration .. Try Again Later";
            }
        }
       
       
}
}
