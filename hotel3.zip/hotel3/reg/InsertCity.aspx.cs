﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace reg
{
    public partial class WebForm14 : System.Web.UI.Page
    {
        Label l1 = new Label();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //city_object ho = new city_object();
            //ho.hotel_name = TextBox2.Text;
            //register_bal ro = new register_bal();
            //string msg = ro.insertcity(ho);
            //if (!msg.Equals("Success"))
            //{

            //    l1.Text = msg;
            //    HyperLink h1 = new HyperLink();
            //    h1.Text = "Login";
            //    Response.Redirect("login.aspx");
            //}

            //else
            //{

            //    l1.Text = "Unsucessful Registration .. Try Again Later";
            //}
            
        }
    }
}