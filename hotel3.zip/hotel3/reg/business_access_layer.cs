﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;

namespace reg.database_con
{
    public class business_access_layer
    {
        public DataSet Offers()
        {
            data_access_layer data_object_VII = new data_access_layer();
            try
            {
                return data_object_VII.Offers();
            }
            catch (Exception error)
            {
                throw error;
            }
            finally
            {
                data_object_VII = null;
            }

        }
    }
}